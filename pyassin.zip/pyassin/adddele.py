my_dict={'keerthi':'181040007','chandan':'181040013','jai':'1810400012','chandana':'18105004'}

#print output
print(my_dict)

#add address 
my_dict['karthik']='181040016'

#print Address 
print(my_dict)

#delete item
my_dict.pop('karthik')

#delete item from the dict
print(my_dict)


