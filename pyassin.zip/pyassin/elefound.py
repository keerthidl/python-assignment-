ListOfStrings=['manipal','SOIS','udupi','mangalore']

print(ListOfStrings)

if 'SOIS' in ListOfStrings:
	print("yes,'SOIS' found in the list: ",ListOfStrings)
	elif print("No,'SOIS' not found in the list ",ListOfStrings)

