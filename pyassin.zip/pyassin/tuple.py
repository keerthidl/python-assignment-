tuple_a = ('Apple', 'Banana', 'kiwi', 'pomegranate')
tuple_b = ('Potato', 'Brinjal', 'idge gourd','cucumber')
y_list = list(zip(tuple_a,tuple_b))

