string=input("Enter the string: ")
print("reverse of the string is: ")
print(string[::-1])