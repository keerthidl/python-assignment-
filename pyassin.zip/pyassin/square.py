number = int(input("enter the number :")) 


square=number**2;


print("the square of number is",square)