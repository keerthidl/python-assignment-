string1=input(" enter the first to concatenate: ");
string2=input("enter the second  to concatenate: ");

string3= string1+string2;

print("string after concatenate is: ", string3);
print("string1=", string1);
print("string2=", string2);
print("string3=", string3);
